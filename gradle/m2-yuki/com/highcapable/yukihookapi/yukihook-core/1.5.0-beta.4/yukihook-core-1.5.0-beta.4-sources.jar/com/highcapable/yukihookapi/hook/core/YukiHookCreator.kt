/*
 * YukiHook - A modern hook API and Xposed module solution.
 * Copyright (C) 2019 HighCapable
 * https://github.com/HighCapable/YukiHook
 *
 * Apache License Version 2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * This file is created by fankes on 2022/2/2.
 */
@file:Suppress("unused")

package com.highcapable.yukihookapi.hook.core

import android.os.Bundle
import com.highcapable.kavaref.extension.classOf
import com.highcapable.kavaref.extension.isNotSubclassOf
import com.highcapable.yukihookapi.YukiHook
import com.highcapable.yukihookapi.hook.core.api.helper.YukiHookHelper
import com.highcapable.yukihookapi.hook.core.api.priority.YukiHookPriority
import com.highcapable.yukihookapi.hook.core.api.result.YukiHookResult
import com.highcapable.yukihookapi.hook.log.YLog
import com.highcapable.yukihookapi.hook.param.HookChain
import com.highcapable.yukihookapi.hook.param.HookInvocation
import com.highcapable.yukihookapi.hook.param.HookParam
import com.highcapable.yukihookapi.runtime.YukiHookBridge
import com.highcapable.yukihookapi.runtime.bridge.hooker.ChainHookerBridge
import com.highcapable.yukihookapi.runtime.bridge.hooker.ClassicHookerBridge
import com.highcapable.yukihookapi.runtime.bridge.hooker.HookPoint
import com.highcapable.yukihookapi.runtime.bridge.hooker.HookerBridge
import java.lang.reflect.Constructor
import java.lang.reflect.Member
import java.lang.reflect.Method
import java.util.concurrent.atomic.AtomicLong

/**
 * Core [Member] hook implementation for [YukiHook].
 *
 * The core API is implemented through [YukiHookHelper].
 */
class YukiHookCreator private constructor() {

    internal companion object {

        /**
         * Creates a chain member hooker.
         * @param targets the points to hook.
         * @param priority the hook priority.
         * @param invocation the interceptor invoked for each call.
         * @return [ChainMemberHooker]
         */
        fun createChainHooker(targets: Collection<HookPoint>, priority: YukiHookPriority, invocation: HookChain.() -> Any?) =
            ChainMemberHooker(priority, invocation).also { it.targets.addAll(targets) }

        /**
         * Creates a classic member hooker.
         * @param targets the points to hook.
         * @param priority the hook priority.
         * @param isLazyMode whether registration waits until the hook block has been configured.
         * @return [ClassicMemberHooker]
         */
        fun createClassicHooker(targets: Collection<HookPoint>, priority: YukiHookPriority, isLazyMode: Boolean) =
            ClassicMemberHooker(priority, if (isLazyMode) HookMode.LAZY else HookMode.IMMEDIATE)
                .also { it.targets.addAll(targets) }
    }

    /**
     * Base member registration and invocation-listener implementation.
     * @param priority the hook priority.
     */
    abstract class MemberHooker<I : HookInvocation> internal constructor(private val priority: YukiHookPriority) {

        private val registrationLock = Any()
        private val result = Result()

        private var isHooked = false
        private var isRegistering = false
        private var isRemovalPending = false

        private var onCallbackFailureCallback: ((I, Throwable) -> Unit)? = null
        private var onInvocationFailureCallback: ((Throwable) -> Unit)? = null

        private val results = mutableSetOf<YukiHookResult>()

        /** Points selected for this registration group. */
        internal val targets = mutableSetOf<HookPoint>()

        /**
         * Removes every registered hook belonging to this hooker.
         * @param callback callback indicating whether any registrations were removed.
         */
        fun removeSelf(callback: (Boolean) -> Unit = {}) = result.remove(callback)

        /**
         * Registers the configured hooker.
         * @return [Result] for removal and invocation failure listeners.
         */
        internal fun build() = result.apply { hook() }

        /** Registers each point independently so one failure does not interrupt the remaining hooks. */
        internal fun hook() {
            if (!YukiHookBridge.isAvailable) return
            val pendingTargets = synchronized(registrationLock) {
                if (isHooked) return

                isHooked = true
                isRegistering = true
                targets.toList()
            }

            runCatching {
                pendingTargets.forEach { target ->
                    runCatching {
                        YukiHookHelper.hook(target, createHooker(target), priority).let(::storeRegistration)
                    }.onFailure { logError(it, target) }
                }
            }.also {
                synchronized(registrationLock) {
                    isRegistering = false
                    isRemovalPending = false
                }
            }.getOrThrow()
        }

        /**
         * Stores a completed registration or removes it when removal was requested while registering.
         * @param registration the completed registration.
         */
        private fun storeRegistration(registration: YukiHookResult) {
            val shouldRemove = synchronized(registrationLock) {
                if (isRemovalPending) true else {
                    results.add(registration)
                    false
                }
            }

            if (shouldRemove) runCatching {
                removeRegistration(registration)
            }.onFailure {
                synchronized(registrationLock) {
                    results.add(registration)
                }
            }.getOrThrow()
        }

        /**
         * Removes one native registration outside [registrationLock].
         * @param registration the registration to remove.
         */
        private fun removeRegistration(registration: YukiHookResult) {
            registration.remove()
            YLog.innerD("Removed hooker for ${registration.target}")
        }

        /** Replaces each currently registered point with a new callback generation. */
        internal fun replaceRegistrations() {
            synchronized(registrationLock) { results.toList() }.forEach { registration ->
                runCatching {
                    replaceRegistration(registration)
                }.getOrElse { throwable ->
                    if (throwable is UnsupportedOperationException) throw throwable
                    logError(throwable, registration.target)
                }
            }
        }

        private fun replaceRegistration(registration: YukiHookResult) {
            synchronized(registrationLock) {
                if (!results.contains(registration)) return

                val replacement = YukiHookHelper.replace(registration, createHooker(registration.target))
                results.remove(registration)
                results.add(replacement)
            }
        }

        /**
         * Creates the runtime hooker for one point.
         * @param target the point being registered.
         * @return [HookerBridge]
         */
        internal abstract fun createHooker(target: HookPoint): HookerBridge

        /**
         * Casts this hooker to the required type.
         * @return [T]
         * @throws IllegalStateException if this hooker is not of the required type.
         */
        internal inline fun <reified T : MemberHooker<*>> asType() = this as? T ?: error("Current hooker is not a type of ${classOf<T>().name}.")

        /**
         * Notifies hooker callback failure listeners without choosing a recovery policy.
         * @param invocation the failed invocation.
         * @param throwable the callback failure.
         */
        protected fun notifyCallbackFailure(invocation: I, throwable: Throwable) {
            onCallbackFailureCallback?.invoke(invocation, throwable)
            onInvocationFailureCallback?.invoke(throwable)
            if (onCallbackFailureCallback == null && onInvocationFailureCallback == null) logError(throwable, invocation.member)
        }

        private fun logError(throwable: Throwable, target: Any) = YLog.innerE("Try to hook $target got an exception", throwable)

        override fun toString() = "${javaClass.simpleName}(members=$targets, priority=$priority, isHooked=$isHooked)"

        /**
         * Registration group handle and invocation failure listeners.
         *
         * Listeners observe subsequent invocation failures only.
         */
        inner class Result internal constructor() {

            /** The [MemberHooker] that owns this result. */
            internal val owner get() = this@MemberHooker

            /**
             * Listens for hooker callback failures with the invocation context.
             *
             * This listener does not change the hooker's exception policy. Chain failures still propagate.
             * @param callback the listener receiving the concrete invocation and its failure.
             * @return [Result]
             */
            fun onCallbackFailure(callback: (I, Throwable) -> Unit): Result {
                onCallbackFailureCallback = callback
                return this
            }

            /**
             * Suppresses default callback failure logging without changing exception propagation.
             * @return [Result]
             */
            fun ignoreCallbackFailure() = onCallbackFailure { _, _ -> }

            /**
             * Listens for invocation failures without receiving the invocation context.
             *
             * This listener is independent of [onCallbackFailure] and does not observe registration failures.
             * It does not change the hooker's exception policy. Chain failures still propagate.
             * @param callback the listener receiving the invocation failure.
             * @return [Result]
             */
            fun onInvocationFailure(callback: (Throwable) -> Unit): Result {
                onInvocationFailureCallback = callback
                return this
            }

            /**
             * Suppresses default invocation failure logging without changing exception propagation.
             *
             * This does not replace the listener configured through [onCallbackFailure].
             * @return [Result]
             */
            fun ignoreInvocationFailure() = onInvocationFailure {}

            /**
             * Removes every registration belonging to this hooker.
             * @param callback callback indicating whether any registrations were removed.
             */
            fun remove(callback: (Boolean) -> Unit = {}) {
                val registrations = synchronized(registrationLock) {
                    val registrations = results.toList()
                    results.clear()

                    if (isRegistering) isRemovalPending = true
                    registrations
                }

                runCatching {
                    registrations.forEach(::removeRegistration)
                }.onFailure {
                    synchronized(registrationLock) {
                        results.addAll(registrations)
                    }
                }.getOrThrow()

                callback(registrations.isNotEmpty())
            }

            // region Deprecated functions for backward compatibility

            /**
             * Listens for hooker callback failures through [onCallbackFailure].
             * @param callback the listener receiving the concrete invocation and its failure.
             * @return [Result]
             */
            @Deprecated(message = "Use onCallbackFailure instead.", replaceWith = ReplaceWith("onCallbackFailure(callback)"))
            fun onConductFailure(callback: (I, Throwable) -> Unit) = onCallbackFailure(callback)

            /** Suppresses default callback failure logging through [ignoreCallbackFailure]. */
            @Deprecated(message = "Use ignoreCallbackFailure instead.", replaceWith = ReplaceWith("ignoreCallbackFailure()"))
            fun ignoredConductFailure() = ignoreCallbackFailure()

            /**
             * Listens for invocation failures through [onInvocationFailure].
             * @param callback the listener receiving the invocation failure.
             * @return [Result]
             */
            @Deprecated(message = "Use onInvocationFailure instead.", replaceWith = ReplaceWith("onInvocationFailure(callback)"))
            fun onAllFailure(callback: (Throwable) -> Unit) = onInvocationFailure(callback)

            /**
             * Suppresses default invocation failure logging through [ignoreInvocationFailure].
             * @return [Result]
             */
            @Deprecated(message = "Use ignoreInvocationFailure instead.", replaceWith = ReplaceWith("ignoreInvocationFailure()"))
            fun ignoredAllFailure() = ignoreInvocationFailure()

            /**
             * Configures this result through [apply].
             * @param block the configuration block.
             * @return [Result]
             */
            @Deprecated(message = "Use apply instead.", replaceWith = ReplaceWith("apply(block)"))
            inline fun result(block: Result.() -> Unit) = apply(block)

            /**
             * This function has no effect and does not evaluate [condition].
             *
             * - Check the condition before registering hooks instead.
             * @param condition the unused condition block.
             * @return [Result]
             */
            @Deprecated(message = "This API has no effect. Check the condition before registering hooks instead.")
            inline fun by(condition: () -> Boolean) = this

            /**
             * This function has no effect and does not invoke [callback].
             *
             * - Registration completes before this result is returned. Remove this call.
             * @param callback the unused registration success listener.
             * @return [Result]
             */
            @Deprecated(message = "This API has no effect. Remove this call.")
            fun onHooked(callback: (Member) -> Unit) = this

            /**
             * This function has no effect and does not invoke [callback].
             *
             * - Registration failures are logged before this result is returned. Remove this call.
             * @param callback the unused registration failure listener.
             * @return [Result]
             */
            @Deprecated(message = "This API has no effect. Remove this call.")
            fun onHookingFailure(callback: (Throwable) -> Unit) = this

            /**
             * This function has no effect and does not suppress registration failure logs.
             *
             * - Remove this call.
             * @return [Result]
             */
            @Deprecated(message = "This API has no effect. Remove this call.")
            fun ignoredHookingFailure() = this

            // endregion
        }
    }

    /**
     * Chain interceptor implementation.
     * @param priority the hook priority.
     * @param invocation the interceptor invoked for each call.
     */
    class ChainMemberHooker internal constructor(
        priority: YukiHookPriority,
        private var invocation: HookChain.() -> Any?
    ) : MemberHooker<HookChain>(priority) {

        private var dataExtra = Bundle()

        /**
         * Replaces the current hooker with a new one.
         * @param invocation the new interceptor invoked for each call.
         */
        internal fun replace(invocation: HookChain.() -> Any?) {
            this.invocation = invocation
            dataExtra = Bundle()
            replaceRegistrations()
        }

        override fun createHooker(target: HookPoint): ChainHookerBridge {
            val invocationCount = AtomicLong()
            val callback = invocation
            val dataExtraStorage = dataExtra

            return ChainHookerBridge { chain ->
                val invocation = HookChain.from(dataExtraStorage, this@ChainMemberHooker, chain)

                runCatching {
                    YLog.innerD("Executing hooker [intercept] (${invocationCount.incrementAndGet()}) for $target")
                    callback(invocation)
                }.getOrElse { throwable ->
                    notifyCallbackFailure(invocation, throwable)

                    // The remaining chain may already have executed, never retry it as failure recovery.
                    throw throwable
                }
            }
        }
    }

    /**
     * Classic before/after and interception hook implementation.
     * @param priority the hook priority.
     * @param hookMode the registration mode.
     */
    class ClassicMemberHooker internal constructor(
        priority: YukiHookPriority,
        private val hookMode: HookMode
    ) : MemberHooker<HookParam>(priority) {

        private class CallbackState {

            var beforeHookCallback: (HookParam.() -> Unit)? = null
            var afterHookCallback: (HookParam.() -> Unit)? = null
            var interceptHookCallback: (HookParam.() -> Any?)? = null

            var throwToHostOnFailure = false
            var isInterceptHookMode = false

            var beforeDataExtra = Bundle()
            var afterDataExtra = Bundle()
            var interceptDataExtra = Bundle()
        }

        private var state = CallbackState()

        /**
         * Replaces the current hooker with a new one.
         * @param hooker the new configuration block.
         */
        internal fun replace(hooker: ClassicMemberHooker.() -> Unit) {
            state = CallbackState()
            hooker(this)
            replaceRegistrations()
        }

        /**
         * Hooks before [Member] execution completes.
         *
         * - Cannot be used together with [intercept].
         * @param callback the [HookParam] function body.
         * @return [HookCallback]
         */
        fun before(callback: HookParam.() -> Unit): HookCallback {
            state.isInterceptHookMode = false
            state.beforeHookCallback = callback
            immediateHook()

            return HookCallback()
        }

        /**
         * Hooks after [Member] execution completes.
         *
         * - Cannot be used together with [intercept].
         * @param callback the [HookParam] function body.
         * @return [HookCallback]
         */
        fun after(callback: HookParam.() -> Unit): HookCallback {
            state.isInterceptHookMode = false
            state.afterHookCallback = callback
            immediateHook()

            return HookCallback()
        }

        /**
         * Intercepts this [Member] with the callback return value.
         *
         * - The callback return value is ignored for void methods and constructors.
         * - Cannot be used together with [before] or [after].
         * @param callback the [HookParam] function body.
         */
        fun intercept(callback: HookParam.() -> Any?) {
            state.isInterceptHookMode = true
            state.interceptHookCallback = callback
            immediateHook()
        }

        /**
         * Intercepts this [Member] with a constant return value.
         *
         * - The [value] is ignored for void methods and constructors.
         * - Note: Setting a [Member] with a constant return value such as [Int], [Long],
         *   or [Boolean] to null may cause the host to throw an exception.
         * - Cannot be used together with [before] or [after].
         * @param value the replacement constant value, null by default.
         */
        fun intercept(value: Any? = null) = intercept { value }

        // region Deprecated functions for backward compatibility

        /** Intercepts and replaces this [Member] with a return value. */
        @Deprecated(message = "Use intercept instead.", replaceWith = ReplaceWith("intercept(callback)"))
        fun replaceAny(callback: HookParam.() -> Any?) = intercept(callback)

        /** Intercepts and replaces this [Member] without a return value ([Unit]). */
        @Deprecated(message = "Use intercept instead.", replaceWith = ReplaceWith("intercept(callback)"))
        fun replaceUnit(callback: HookParam.() -> Unit) = intercept(callback)

        /** Intercepts and replaces the [Member] return value. */
        @Deprecated(message = "Use intercept instead.", replaceWith = ReplaceWith("intercept(any)"))
        fun replaceTo(any: Any?) = intercept(any)

        /** Intercepts and replaces the [Member] return value with true. */
        @Deprecated(message = "Use intercept instead.", replaceWith = ReplaceWith("intercept(true)"))
        fun replaceToTrue() = intercept(true)

        /** Intercepts and replaces the [Member] return value with false. */
        @Deprecated(message = "Use intercept instead.", replaceWith = ReplaceWith("intercept(false)"))
        fun replaceToFalse() = intercept(false)

        // endregion

        private fun immediateHook() {
            if (hookMode == HookMode.IMMEDIATE) hook()
        }

        override fun createHooker(target: HookPoint): ClassicHookerBridge {
            // The mode is fixed at registration, even if the creator is configured again later.
            val state = state
            val isInterception = state.isInterceptHookMode

            return object : ClassicHookerBridge {

                private val beforeInvocationCount = AtomicLong()
                private val afterInvocationCount = AtomicLong()

                override fun beforeHookedMember(param: ClassicHookerBridge.Param) {
                    val invocation = HookParam.from(
                        dataExtraStorage = if (isInterception) state.interceptDataExtra else state.beforeDataExtra,
                        this@ClassicMemberHooker, param
                    )

                    val result = runCatching {
                        val callback = if (isInterception) state.interceptHookCallback else state.beforeHookCallback
                        if (callback != null) YLog.innerD(
                            "Executing hooker [${if (isInterception) "intercept" else "before"}] " +
                                "(${beforeInvocationCount.incrementAndGet()}) for $target"
                        )

                        val value = callback?.invoke(invocation)
                        val returnType = (param.member as? Method?)?.returnType
                        val isReturnIgnored = param.member is Constructor<*> || returnType == Void.TYPE
                        val interceptedValue = if (isInterception && isReturnIgnored) null else value
                        val target = (if (isInterception) interceptedValue else param.result)?.javaClass

                        checkingReturnType(returnType, target)

                        interceptedValue
                    }.getOrElse {
                        notifyCallbackFailure(invocation, it)

                        // A failed interception invokes the original unhooked `Member` to keep the host running normally.
                        if (isInterception) invocation.callOriginal() else {
                            if (state.throwToHostOnFailure) param.throwable = it
                            null
                        }
                    }
                    if (isInterception) param.result = result
                }

                override fun afterHookedMember(param: ClassicHookerBridge.Param) {
                    if (isInterception) return

                    HookParam.from(state.afterDataExtra, this@ClassicMemberHooker, param).also { invocation ->
                        runCatching {
                            val callback = state.afterHookCallback
                            if (callback != null) {
                                YLog.innerD("Executing hooker [after] (${afterInvocationCount.incrementAndGet()}) for $target")
                                callback(invocation)
                            }
                        }.onFailure {
                            notifyCallbackFailure(invocation, it)
                            if (state.throwToHostOnFailure) param.throwable = it
                        }
                    }
                }
            }
        }

        /**
         * Checks the return value of the hooked [Member].
         * @param origin the original return value.
         * @param target the target return value.
         * @throws IllegalStateException if the return value is incorrect.
         */
        private fun checkingReturnType(origin: Class<*>?, target: Class<*>?) {
            if (origin == null || target == null) return
            if (origin == classOf<Any>()) return

            origin.asHookReturnType().also { o ->
                target.asHookReturnType().also { t ->
                    if (t isNotSubclassOf o) error("Hooked method return type match failed, required $origin but got $target")
                }
            }
        }

        /** Normalizes boxed primitives and Kotlin [Unit] to their JVM Hook return types. */
        private fun Class<*>.asHookReturnType() = if (this == classOf<Unit>()) Void.TYPE else kotlin.javaPrimitiveType ?: this

        /**
         * Hook callback body implementation.
         */
        inner class HookCallback internal constructor() {

            /** Throws an exception to the current host when one occurs in the callback body. */
            fun throwToHostOnFailure() {
                state.throwToHostOnFailure = true
            }

            /** Throws an exception to the current host when one occurs in the callback body. */
            @Deprecated(message = "Use throwToHostOnFailure instead.", replaceWith = ReplaceWith("throwToHostOnFailure()"))
            fun onFailureThrowToApp() = throwToHostOnFailure()
        }
    }

    /**
     * Hook mode type definition.
     */
    internal enum class HookMode {
        /** Lazy mode. */
        LAZY,

        /** Immediate mode. */
        IMMEDIATE
    }
}