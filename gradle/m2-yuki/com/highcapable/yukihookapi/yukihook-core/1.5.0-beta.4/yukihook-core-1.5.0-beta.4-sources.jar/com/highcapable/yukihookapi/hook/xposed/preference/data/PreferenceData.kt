/*
 * YukiHook - A modern hook API and Xposed module solution.
 * Copyright (C) 2019 HighCapable
 * https://github.com/HighCapable/YukiHook
 *
 * Apache License Version 2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * This file is created by fankes on 2022/3/27.
 */
package com.highcapable.yukihookapi.hook.xposed.preference.data

import com.highcapable.yukihookapi.hook.xposed.preference.YukiHookPreferences
import java.io.Serializable

/**
 * Defines a typed key-value preference entry.
 *
 * This class provides an extended usage pattern for [YukiHookPreferences].
 * @param key the preference key.
 * @param value the default value.
 */
data class PreferenceData<T>(
    var key: String,
    var value: T
) : Serializable