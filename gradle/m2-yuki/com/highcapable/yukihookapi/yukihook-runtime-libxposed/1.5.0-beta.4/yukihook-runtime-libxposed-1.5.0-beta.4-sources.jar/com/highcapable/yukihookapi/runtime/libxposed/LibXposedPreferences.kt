/*
 * YukiHook - A modern hook API and Xposed module solution.
 * Copyright (C) 2019 HighCapable
 * https://github.com/HighCapable/YukiHook
 *
 * Apache License Version 2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * This file is created by fankes on 2026/9/8.
 */
package com.highcapable.yukihookapi.runtime.libxposed

import android.content.Context
import android.content.SharedPreferences
import io.github.libxposed.api.XposedInterface

/**
 * Remote preferences with private module storage as the inactive fallback.
 */
internal object LibXposedPreferences {

    fun open(context: Context?, name: String): SharedPreferences {
        if (context == null) return Host.open(name)
        return Module.open(context, name)
    }

    fun attach(api: XposedInterface) = Host.attach(api)

    private object Module {

        fun open(context: Context, name: String): SharedPreferences =
            LibXposedService.preferencesOrNull(name) ?: context.getSharedPreferences(name, Context.MODE_PRIVATE)
    }

    private object Host {

        private var xposedApi: XposedInterface? = null

        private val api get() = checkNotNull(xposedApi) {
            "libxposed host remote preferences are unavailable."
        }

        fun attach(api: XposedInterface) {
            xposedApi = api
        }

        fun open(name: String): SharedPreferences {
            check(api.frameworkProperties and XposedInterface.PROP_CAP_REMOTE != 0L) {
                "This framework does not support remote preferences."
            }

            return api.getRemotePreferences(name)
        }
    }
}